# NOTE

This is mainly the v0.32 typings with simple updates for v1.

The level of v1 compliance will improve over time.
