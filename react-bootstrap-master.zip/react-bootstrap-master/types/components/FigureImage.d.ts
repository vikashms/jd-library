import Image from './Image';

declare class FigureImage extends Image {}

export default FigureImage;
