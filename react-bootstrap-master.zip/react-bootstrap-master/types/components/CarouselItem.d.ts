import { BsPrefixComponent } from './helpers';

declare class CarouselItem extends BsPrefixComponent<'div'> {}

export default CarouselItem;
