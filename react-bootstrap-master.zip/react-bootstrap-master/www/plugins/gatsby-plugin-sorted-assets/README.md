# gatsby-plugin-sorted-assets

A workaround for gatsby not sorting order-dependent assets, like css, in it's html building.

This should be moved to gatsby core, there is a pending PR to do so.
