<Form inline>
  <Form.Group controlId="formInlineName">
    <Form.Label>Name</Form.Label>{' '}
    <Form.Control type="text" placeholder="Jane Doe" />
  </Form.Group>{' '}
  <Form.Group controlId="formInlineEmail">
    <Form.Label>Email</Form.Label>{' '}
    <Form.Control type="email" placeholder="jane.doe@example.com" />
  </Form.Group>{' '}
  <Button type="submit">Send invitation</Button>
</Form>;
