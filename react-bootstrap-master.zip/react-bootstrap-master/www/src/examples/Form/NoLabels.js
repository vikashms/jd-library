<>
  <Form.Check aria-label="option 1" />
  <Form.Check type="radio" aria-label="radio 1" />
</>;
