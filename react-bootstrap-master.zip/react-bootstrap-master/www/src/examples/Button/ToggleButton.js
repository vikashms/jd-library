<div className="d-flex flex-column">
  <ButtonGroup toggle>
    <ToggleButton type="checkbox" defaultChecked value="1">
      Checked
    </ToggleButton>
  </ButtonGroup>
  <ButtonGroup toggle className="mt-3">
    <ToggleButton type="radio" name="radio" defaultChecked value="1">
      Active
    </ToggleButton>
    <ToggleButton type="radio" name="radio" value="2">
      Radio
    </ToggleButton>
    <ToggleButton type="radio" name="radio" value="3">
      Radio
    </ToggleButton>
  </ButtonGroup>
</div>;
