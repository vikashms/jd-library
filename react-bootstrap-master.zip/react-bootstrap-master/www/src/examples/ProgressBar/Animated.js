<ProgressBar animated now={45} />;
