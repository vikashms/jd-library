<ProgressBar now={60} />;
