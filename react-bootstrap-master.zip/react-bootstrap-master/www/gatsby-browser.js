require('./src/css/global.scss');

exports.wrapPageElement = require(`./src/wrap-page`);
