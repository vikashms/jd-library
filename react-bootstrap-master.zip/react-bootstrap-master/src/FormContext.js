import React from 'react';

const FormContext = React.createContext({ controlId: undefined });

export default FormContext;
