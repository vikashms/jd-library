import React from 'react';

const ModalContext = React.createContext({ onHide() {} });

export default ModalContext;
