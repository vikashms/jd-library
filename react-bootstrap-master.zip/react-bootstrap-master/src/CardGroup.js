import createWithBsPrefix from './utils/createWithBsPrefix';

export default createWithBsPrefix('card-group');
