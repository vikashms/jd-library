import React from 'react';

const NavContext = React.createContext(null);

export default NavContext;
