import React from 'react';

const TabContext = React.createContext(null);

export default TabContext;
